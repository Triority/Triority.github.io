/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306.h"
#include "stdio.h"
#include "Delay.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int ERR = 0;
char bufnum[7];
volatile uint16_t ADC_Value[9];
uint16_t ADC_Vout,ADC_Fb,ADC_Vin,ADC_TEMP0,ADC_TEMP1,ADC_KNOB0,ADC_KNOB1,ADC_SW,ADC_TEMPSTM;
float Vout,Iout,Vin,TEMP0,TEMP1,KNOB0,KNOB1,SW,TEMPSTM;
int status_SW,status_KNOB;
int DIM_9209;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_I2C1_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_Base_Start_IT(&htim3);
	HAL_TIM_PWM_Start (&htim2,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start (&htim2,TIM_CHANNEL_2);
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)&ADC_Value, 9);
	
	SSD1306_Init ();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	

	
	while (1)
  {
		//EN
		if(ERR||status_SW==1){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET);
		}else{
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET);
		}
		//ADC
		ADC_Vout=ADC_Value[0];
		ADC_Fb=ADC_Value[1];
		ADC_Vin=ADC_Value[2];
		ADC_TEMP0=ADC_Value[3];
		ADC_TEMP1=ADC_Value[4];
		ADC_KNOB0=ADC_Value[5];
		ADC_KNOB1=ADC_Value[6];
		ADC_SW=ADC_Value[7];
		ADC_TEMPSTM=ADC_Value[8];
		Vout=(float)ADC_Vout * 3.3f * 11.0f/ 4095.0f;
		Iout=(float)ADC_Fb * 3.3f / 0.0125f / 4095.0f;
		Vin=(float)ADC_Vin * 3.3f * 11.0f / 4095.0f;
		TEMP0=(float)ADC_TEMP0 * 3.3f / 4095.0f;
		TEMP1=(float)ADC_TEMP1 * 3.3f / 4095.0f;
		KNOB0=(float)ADC_KNOB0 / 4095.0f;
		KNOB1=(float)ADC_KNOB1 / 4095.0f;
		SW=(float)ADC_SW / 4095.0f;
		TEMPSTM=(1.43f - ((float)ADC_TEMPSTM * 3.3f / 4095.0f))/0.0043f + 25.0f;
		//status
		status_KNOB = (int)(KNOB0*20)*10+(int)(KNOB1*20.0f);
		if(status_KNOB>100)status_KNOB=100;
		if(SW>0.66f){status_SW=2;}else if(SW>0.33f){status_SW=1;}else{status_SW=0;}
		//DIM pwm
		DIM_9209 = 10 + status_KNOB*989/100;
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, DIM_9209);
		
		
	}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	  if(htim == &htim3)
	 {
	    HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_13);
		 //oled
		  SSD1306_GotoXY (0,0);
			sprintf (bufnum, "PWM%03d", DIM_9209);
			SSD1306_Puts (bufnum, &Font_11x18, 1);
			SSD1306_GotoXY (0,20);
			sprintf (bufnum, "Vo:%03.1f", Vout);
			SSD1306_Puts (bufnum, &Font_11x18, 1);
			SSD1306_GotoXY (0,40);
			sprintf (bufnum, "Io:%03.1f", Iout);
			SSD1306_Puts (bufnum, &Font_11x18, 1);
			SSD1306_UpdateScreen();
	 }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
