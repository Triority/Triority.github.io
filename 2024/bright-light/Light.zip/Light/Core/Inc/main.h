/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_Pin GPIO_PIN_13
#define LED_GPIO_Port GPIOC
#define VO_Pin GPIO_PIN_0
#define VO_GPIO_Port GPIOA
#define FB_Pin GPIO_PIN_1
#define FB_GPIO_Port GPIOA
#define VCC_S_Pin GPIO_PIN_2
#define VCC_S_GPIO_Port GPIOA
#define TEM0_Pin GPIO_PIN_3
#define TEM0_GPIO_Port GPIOA
#define TEM1_Pin GPIO_PIN_4
#define TEM1_GPIO_Port GPIOA
#define KNOB0_Pin GPIO_PIN_5
#define KNOB0_GPIO_Port GPIOA
#define KNOB1_Pin GPIO_PIN_6
#define KNOB1_GPIO_Port GPIOA
#define SW_Pin GPIO_PIN_1
#define SW_GPIO_Port GPIOB
#define PWM_FAN_Pin GPIO_PIN_15
#define PWM_FAN_GPIO_Port GPIOA
#define DIM_Pin GPIO_PIN_3
#define DIM_GPIO_Port GPIOB
#define EN_Pin GPIO_PIN_4
#define EN_GPIO_Port GPIOB
#define RPM_FAN_Pin GPIO_PIN_5
#define RPM_FAN_GPIO_Port GPIOB
#define RPM_FAN_EXTI_IRQn EXTI9_5_IRQn

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
